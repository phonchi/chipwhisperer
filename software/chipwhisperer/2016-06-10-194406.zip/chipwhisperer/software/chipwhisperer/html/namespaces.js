var namespaces =
[
    [ "Flowchart", "d3/dbe/namespaceFlowchart.html", null ],
    [ "FlowChartWidget", "d1/d91/namespaceFlowChartWidget.html", null ],
    [ "software", "df/dec/namespacesoftware.html", "df/dec/namespacesoftware" ]
];