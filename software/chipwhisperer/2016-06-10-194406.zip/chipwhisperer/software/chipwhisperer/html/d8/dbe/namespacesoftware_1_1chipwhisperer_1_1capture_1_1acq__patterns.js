var namespacesoftware_1_1chipwhisperer_1_1capture_1_1acq__patterns =
[
    [ "_base", "d0/d89/namespacesoftware_1_1chipwhisperer_1_1capture_1_1acq__patterns_1_1__base.html", "d0/d89/namespacesoftware_1_1chipwhisperer_1_1capture_1_1acq__patterns_1_1__base" ],
    [ "basic", "db/d25/namespacesoftware_1_1chipwhisperer_1_1capture_1_1acq__patterns_1_1basic.html", "db/d25/namespacesoftware_1_1chipwhisperer_1_1capture_1_1acq__patterns_1_1basic" ],
    [ "crittest", "dd/d93/namespacesoftware_1_1chipwhisperer_1_1capture_1_1acq__patterns_1_1crittest.html", "dd/d93/namespacesoftware_1_1chipwhisperer_1_1capture_1_1acq__patterns_1_1crittest" ]
];