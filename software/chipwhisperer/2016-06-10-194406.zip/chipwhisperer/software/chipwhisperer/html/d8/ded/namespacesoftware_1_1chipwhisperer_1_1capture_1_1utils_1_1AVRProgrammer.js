var namespacesoftware_1_1chipwhisperer_1_1capture_1_1utils_1_1AVRProgrammer =
[
    [ "AVRProgrammer", "da/db4/classsoftware_1_1chipwhisperer_1_1capture_1_1utils_1_1AVRProgrammer_1_1AVRProgrammer.html", "da/db4/classsoftware_1_1chipwhisperer_1_1capture_1_1utils_1_1AVRProgrammer_1_1AVRProgrammer" ],
    [ "AVRProgrammerDialog", "da/d5c/classsoftware_1_1chipwhisperer_1_1capture_1_1utils_1_1AVRProgrammer_1_1AVRProgrammerDialog.html", "da/d5c/classsoftware_1_1chipwhisperer_1_1capture_1_1utils_1_1AVRProgrammer_1_1AVRProgrammerDialog" ]
];