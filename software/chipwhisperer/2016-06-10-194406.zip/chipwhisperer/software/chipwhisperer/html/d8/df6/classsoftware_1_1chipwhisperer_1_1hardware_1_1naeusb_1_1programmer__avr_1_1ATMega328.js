var classsoftware_1_1chipwhisperer_1_1hardware_1_1naeusb_1_1programmer__avr_1_1ATMega328 =
[
    [ "memtypes", "d8/df6/classsoftware_1_1chipwhisperer_1_1hardware_1_1naeusb_1_1programmer__avr_1_1ATMega328.html#a0ae71c3cc284c6bf094fe48b20298714", null ],
    [ "name", "d8/df6/classsoftware_1_1chipwhisperer_1_1hardware_1_1naeusb_1_1programmer__avr_1_1ATMega328.html#a417809ff45aa4bc6f977aaf6b349ab86", null ],
    [ "signature", "d8/df6/classsoftware_1_1chipwhisperer_1_1hardware_1_1naeusb_1_1programmer__avr_1_1ATMega328.html#a658db9ba7e3a3e6b1a4bc1b3ce66a915", null ]
];