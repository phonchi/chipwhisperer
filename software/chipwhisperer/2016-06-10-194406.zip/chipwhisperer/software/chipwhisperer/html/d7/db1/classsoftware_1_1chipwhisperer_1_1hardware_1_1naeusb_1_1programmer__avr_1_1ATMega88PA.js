var classsoftware_1_1chipwhisperer_1_1hardware_1_1naeusb_1_1programmer__avr_1_1ATMega88PA =
[
    [ "memtypes", "d7/db1/classsoftware_1_1chipwhisperer_1_1hardware_1_1naeusb_1_1programmer__avr_1_1ATMega88PA.html#a361a12da79ec952db38249b8f058ede8", null ],
    [ "name", "d7/db1/classsoftware_1_1chipwhisperer_1_1hardware_1_1naeusb_1_1programmer__avr_1_1ATMega88PA.html#ab24a0e8314553eff75a747f4d671b766", null ],
    [ "signature", "d7/db1/classsoftware_1_1chipwhisperer_1_1hardware_1_1naeusb_1_1programmer__avr_1_1ATMega88PA.html#a0e3412ed434488062014bba19ef137bc", null ]
];