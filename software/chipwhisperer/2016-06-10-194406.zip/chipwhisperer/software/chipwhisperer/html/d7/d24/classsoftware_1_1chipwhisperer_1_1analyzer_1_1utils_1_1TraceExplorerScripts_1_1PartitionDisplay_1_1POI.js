var classsoftware_1_1chipwhisperer_1_1analyzer_1_1utils_1_1TraceExplorerScripts_1_1PartitionDisplay_1_1POI =
[
    [ "__init__", "d7/d24/classsoftware_1_1chipwhisperer_1_1analyzer_1_1utils_1_1TraceExplorerScripts_1_1PartitionDisplay_1_1POI.html#afc94ebe517ab338a82b581c7036c7ffa", null ],
    [ "calcPOI", "d7/d24/classsoftware_1_1chipwhisperer_1_1analyzer_1_1utils_1_1TraceExplorerScripts_1_1PartitionDisplay_1_1POI.html#ae8c81958a7b5ef2e7f018b280b7d0b25", null ],
    [ "savePOI", "d7/d24/classsoftware_1_1chipwhisperer_1_1analyzer_1_1utils_1_1TraceExplorerScripts_1_1PartitionDisplay_1_1POI.html#ad546799627b06ad46316556fa62713eb", null ],
    [ "setDifferences", "d7/d24/classsoftware_1_1chipwhisperer_1_1analyzer_1_1utils_1_1TraceExplorerScripts_1_1PartitionDisplay_1_1POI.html#a4547beeeea7a868c95d44311d054dfcb", null ],
    [ "diffs", "d7/d24/classsoftware_1_1chipwhisperer_1_1analyzer_1_1utils_1_1TraceExplorerScripts_1_1PartitionDisplay_1_1POI.html#a82aa66ff95bc2a0a00bf0462ccb813d6", null ],
    [ "mainTable", "d7/d24/classsoftware_1_1chipwhisperer_1_1analyzer_1_1utils_1_1TraceExplorerScripts_1_1PartitionDisplay_1_1POI.html#a7fe266919c72a3e1dd148b0eebf63fc7", null ],
    [ "parent", "d7/d24/classsoftware_1_1chipwhisperer_1_1analyzer_1_1utils_1_1TraceExplorerScripts_1_1PartitionDisplay_1_1POI.html#a5365ab9885cd9f79ca294ebd0a48fdda", null ],
    [ "poiArray", "d7/d24/classsoftware_1_1chipwhisperer_1_1analyzer_1_1utils_1_1TraceExplorerScripts_1_1PartitionDisplay_1_1POI.html#adbe8e862b81ccc918b44d82cb1f3fe6d", null ]
];