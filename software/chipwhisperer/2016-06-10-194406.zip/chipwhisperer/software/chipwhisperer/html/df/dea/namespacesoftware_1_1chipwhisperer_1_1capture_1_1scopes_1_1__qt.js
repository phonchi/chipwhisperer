var namespacesoftware_1_1chipwhisperer_1_1capture_1_1scopes_1_1__qt =
[
    [ "OpenADCQt", "d6/d2f/classsoftware_1_1chipwhisperer_1_1capture_1_1scopes_1_1__qt_1_1OpenADCQt.html", "d6/d2f/classsoftware_1_1chipwhisperer_1_1capture_1_1scopes_1_1__qt_1_1OpenADCQt" ]
];