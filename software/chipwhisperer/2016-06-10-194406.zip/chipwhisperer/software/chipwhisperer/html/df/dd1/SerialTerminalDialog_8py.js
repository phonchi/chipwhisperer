var SerialTerminalDialog_8py =
[
    [ "SerialTerminalDialog", "d2/d9e/classsoftware_1_1chipwhisperer_1_1capture_1_1utils_1_1SerialTerminalDialog_1_1SerialTerminalDialog.html", "d2/d9e/classsoftware_1_1chipwhisperer_1_1capture_1_1utils_1_1SerialTerminalDialog_1_1SerialTerminalDialog" ],
    [ "main", "df/dd1/SerialTerminalDialog_8py.html#aa64752c18c35a6cbee8a910c36199454", null ]
];