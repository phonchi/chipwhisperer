var classsoftware_1_1chipwhisperer_1_1common_1_1results_1_1save_1_1ResultsSave =
[
    [ "__init__", "df/d61/classsoftware_1_1chipwhisperer_1_1common_1_1results_1_1save_1_1ResultsSave.html#a1a04696aba8890ac76be86c7cc40895d", null ],
    [ "analysisUpdated", "df/d61/classsoftware_1_1chipwhisperer_1_1common_1_1results_1_1save_1_1ResultsSave.html#af085523ae618bb17e3f82411c7a26496", null ],
    [ "processAnalysis", "df/d61/classsoftware_1_1chipwhisperer_1_1common_1_1results_1_1save_1_1ResultsSave.html#ae45d6f987a479e7e27aa070759899042", null ],
    [ "setEnabled", "df/d61/classsoftware_1_1chipwhisperer_1_1common_1_1results_1_1save_1_1ResultsSave.html#aeea37dece50414d5283dfc93c86c1328", null ],
    [ "dataarray", "df/d61/classsoftware_1_1chipwhisperer_1_1common_1_1results_1_1save_1_1ResultsSave.html#a8c2555db9c212b301a0974d00ae76b8b", null ]
];