var classsoftware_1_1chipwhisperer_1_1hardware_1_1naeusb_1_1programmer__avr_1_1AVRBase =
[
    [ "bytedelay", "df/d0c/classsoftware_1_1chipwhisperer_1_1hardware_1_1naeusb_1_1programmer__avr_1_1AVRBase.html#a03ff20cee4af5e4835cbc95d0f713848", null ],
    [ "cmdexedelay", "df/d0c/classsoftware_1_1chipwhisperer_1_1hardware_1_1naeusb_1_1programmer__avr_1_1AVRBase.html#a0855277072f4f0025754f8d20ee1922d", null ],
    [ "memtypes", "df/d0c/classsoftware_1_1chipwhisperer_1_1hardware_1_1naeusb_1_1programmer__avr_1_1AVRBase.html#a065728e535a001c7fbd3bf3215a16806", null ],
    [ "name", "df/d0c/classsoftware_1_1chipwhisperer_1_1hardware_1_1naeusb_1_1programmer__avr_1_1AVRBase.html#af15f7f658b5661c34c1e32514db127b2", null ],
    [ "pollindex", "df/d0c/classsoftware_1_1chipwhisperer_1_1hardware_1_1naeusb_1_1programmer__avr_1_1AVRBase.html#a55a6e872347668de0f7b20cd833d8bcc", null ],
    [ "pollmethod", "df/d0c/classsoftware_1_1chipwhisperer_1_1hardware_1_1naeusb_1_1programmer__avr_1_1AVRBase.html#a3739cf95fc9f0d705f417f852aa46499", null ],
    [ "pollvalue", "df/d0c/classsoftware_1_1chipwhisperer_1_1hardware_1_1naeusb_1_1programmer__avr_1_1AVRBase.html#ac542b4a1971547756a519009ba22e9c2", null ],
    [ "postdelay", "df/d0c/classsoftware_1_1chipwhisperer_1_1hardware_1_1naeusb_1_1programmer__avr_1_1AVRBase.html#aad5d0a8059093fb5067506a00d48fbb8", null ],
    [ "predelay", "df/d0c/classsoftware_1_1chipwhisperer_1_1hardware_1_1naeusb_1_1programmer__avr_1_1AVRBase.html#a01277f8dbb2100667fbf97102b19ebf6", null ],
    [ "signature", "df/d0c/classsoftware_1_1chipwhisperer_1_1hardware_1_1naeusb_1_1programmer__avr_1_1AVRBase.html#a398a4d600ff1c2713fc3685b10797d11", null ],
    [ "stabdelay", "df/d0c/classsoftware_1_1chipwhisperer_1_1hardware_1_1naeusb_1_1programmer__avr_1_1AVRBase.html#a46d59905ac47fec2693c6a21cfa905d7", null ],
    [ "synchloops", "df/d0c/classsoftware_1_1chipwhisperer_1_1hardware_1_1naeusb_1_1programmer__avr_1_1AVRBase.html#a4975f3c6629c4fed95aa8102316e61a8", null ],
    [ "timeout", "df/d0c/classsoftware_1_1chipwhisperer_1_1hardware_1_1naeusb_1_1programmer__avr_1_1AVRBase.html#a9c709727efbca87100cdfa5c95fc6a22", null ]
];