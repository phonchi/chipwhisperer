var namespacesoftware_1_1chipwhisperer_1_1capture_1_1scopes_1_1__base =
[
    [ "ScopeTemplate", "df/dff/classsoftware_1_1chipwhisperer_1_1capture_1_1scopes_1_1__base_1_1ScopeTemplate.html", "df/dff/classsoftware_1_1chipwhisperer_1_1capture_1_1scopes_1_1__base_1_1ScopeTemplate" ]
];