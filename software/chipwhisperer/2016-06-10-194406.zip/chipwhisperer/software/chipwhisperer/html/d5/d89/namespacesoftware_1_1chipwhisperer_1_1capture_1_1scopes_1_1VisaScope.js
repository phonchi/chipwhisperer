var namespacesoftware_1_1chipwhisperer_1_1capture_1_1scopes_1_1VisaScope =
[
    [ "VisaScopeInterface", "d6/d21/classsoftware_1_1chipwhisperer_1_1capture_1_1scopes_1_1VisaScope_1_1VisaScopeInterface.html", "d6/d21/classsoftware_1_1chipwhisperer_1_1capture_1_1scopes_1_1VisaScope_1_1VisaScopeInterface" ]
];