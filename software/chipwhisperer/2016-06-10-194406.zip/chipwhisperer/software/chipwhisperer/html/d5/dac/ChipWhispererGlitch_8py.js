var ChipWhispererGlitch_8py =
[
    [ "ChipWhispererGlitch", "d9/d0b/classsoftware_1_1chipwhisperer_1_1capture_1_1scopes_1_1cwhardware_1_1ChipWhispererGlitch_1_1ChipWhispererGlitch.html", "d9/d0b/classsoftware_1_1chipwhisperer_1_1capture_1_1scopes_1_1cwhardware_1_1ChipWhispererGlitch_1_1ChipWhispererGlitch" ],
    [ "SIGNEXT", "d5/dac/ChipWhispererGlitch_8py.html#ae2bb44739036038b47bd62db2df4b185", null ],
    [ "CODE_READ", "d5/dac/ChipWhispererGlitch_8py.html#aed668a4e83d5db567328fb8e2ecfe0a3", null ],
    [ "CODE_WRITE", "d5/dac/ChipWhispererGlitch_8py.html#a9285ed127a4225afd9c39d87953c6724", null ],
    [ "glitchaddr", "d5/dac/ChipWhispererGlitch_8py.html#ae07d5046741e7341b51127ae3cfc6039", null ],
    [ "glitchoffsetaddr", "d5/dac/ChipWhispererGlitch_8py.html#a4152d20f6b1e47093e5a66552b11d09c", null ]
];