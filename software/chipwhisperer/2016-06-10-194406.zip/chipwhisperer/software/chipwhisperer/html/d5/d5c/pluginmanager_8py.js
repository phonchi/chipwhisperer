var pluginmanager_8py =
[
    [ "Plugin", "db/dff/classsoftware_1_1chipwhisperer_1_1common_1_1utils_1_1pluginmanager_1_1Plugin.html", [
      [ "PluginStatusDialog", "dc/d51/classsoftware_1_1chipwhisperer_1_1common_1_1utils_1_1pluginmanager_1_1Plugin_1_1PluginStatusDialog.html", "dc/d51/classsoftware_1_1chipwhisperer_1_1common_1_1utils_1_1pluginmanager_1_1Plugin_1_1PluginStatusDialog" ]
    ] ],
    [ "PluginStatusDialog", "dc/d51/classsoftware_1_1chipwhisperer_1_1common_1_1utils_1_1pluginmanager_1_1Plugin_1_1PluginStatusDialog.html", "dc/d51/classsoftware_1_1chipwhisperer_1_1common_1_1utils_1_1pluginmanager_1_1Plugin_1_1PluginStatusDialog" ],
    [ "getPluginClassesFromModules", "d5/d5c/pluginmanager_8py.html#a64b8a11fb7e35e9c3c566f71a40c1581", null ],
    [ "getPluginsInDictFromPackage", "d5/d5c/pluginmanager_8py.html#ab548f765a1943ab1d23c0126a1c43e5b", null ],
    [ "importModulesInPackage", "d5/d5c/pluginmanager_8py.html#ab676ad867096bb4c10184958fdb64699", null ],
    [ "module_reorder", "d5/d5c/pluginmanager_8py.html#add0e94e268386b288202476fe5f34d64", null ],
    [ "putInDict", "d5/d5c/pluginmanager_8py.html#aef75a345b6737524966068654fab2415", null ],
    [ "loadedItems", "d5/d5c/pluginmanager_8py.html#ad3fbdbdc78196085b0709f08be567525", null ]
];