var classsoftware_1_1chipwhisperer_1_1capture_1_1scopes_1_1__OpenADCInterface_1_1GainSettings =
[
    [ "__init__", "dd/ddd/classsoftware_1_1chipwhisperer_1_1capture_1_1scopes_1_1__OpenADCInterface_1_1GainSettings.html#a3156c2b37e5de144a8bd6e1d27eb5b51", null ],
    [ "gain", "dd/ddd/classsoftware_1_1chipwhisperer_1_1capture_1_1scopes_1_1__OpenADCInterface_1_1GainSettings.html#a8674b84469ef6fb9c0ce17aecc2ba680", null ],
    [ "gainDB", "dd/ddd/classsoftware_1_1chipwhisperer_1_1capture_1_1scopes_1_1__OpenADCInterface_1_1GainSettings.html#a7115a77df5cf92c6a76ecbf77815400e", null ],
    [ "mode", "dd/ddd/classsoftware_1_1chipwhisperer_1_1capture_1_1scopes_1_1__OpenADCInterface_1_1GainSettings.html#a4134b99274dc42613327d4bb577cd029", null ],
    [ "setGain", "dd/ddd/classsoftware_1_1chipwhisperer_1_1capture_1_1scopes_1_1__OpenADCInterface_1_1GainSettings.html#a79d5f54bcfa4e5c15f38e75bb866284e", null ],
    [ "setInterface", "dd/ddd/classsoftware_1_1chipwhisperer_1_1capture_1_1scopes_1_1__OpenADCInterface_1_1GainSettings.html#a090ebf3f79f14a254635d31ed47038b5", null ],
    [ "setMode", "dd/ddd/classsoftware_1_1chipwhisperer_1_1capture_1_1scopes_1_1__OpenADCInterface_1_1GainSettings.html#a0258923992f3439f0c5cce42be208897", null ],
    [ "gain_cached", "dd/ddd/classsoftware_1_1chipwhisperer_1_1capture_1_1scopes_1_1__OpenADCInterface_1_1GainSettings.html#a1054d1e2bc90679afc51d51cfe30ca7a", null ],
    [ "gainlow_cached", "dd/ddd/classsoftware_1_1chipwhisperer_1_1capture_1_1scopes_1_1__OpenADCInterface_1_1GainSettings.html#a3e63ec24ee836d894086be03fafab083", null ],
    [ "name", "dd/ddd/classsoftware_1_1chipwhisperer_1_1capture_1_1scopes_1_1__OpenADCInterface_1_1GainSettings.html#a821d43343196e49eea3fcd7ad2815af2", null ],
    [ "oa", "dd/ddd/classsoftware_1_1chipwhisperer_1_1capture_1_1scopes_1_1__OpenADCInterface_1_1GainSettings.html#ab4a1ae0c6f8dca94fee4757314a227bd", null ],
    [ "param", "dd/ddd/classsoftware_1_1chipwhisperer_1_1capture_1_1scopes_1_1__OpenADCInterface_1_1GainSettings.html#ab2fbbbb1845ef81b590848f5580a1e19", null ]
];