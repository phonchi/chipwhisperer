var classsoftware_1_1chipwhisperer_1_1common_1_1ui_1_1projectdiffwidget_1_1ProjectDiffWidget =
[
    [ "__init__", "dd/d55/classsoftware_1_1chipwhisperer_1_1common_1_1ui_1_1projectdiffwidget_1_1ProjectDiffWidget.html#a34d1b846d20513185791ceb223a2d7d6", null ],
    [ "checkDiff", "dd/d55/classsoftware_1_1chipwhisperer_1_1common_1_1ui_1_1projectdiffwidget_1_1ProjectDiffWidget.html#aa32275c546269f859ccbb4c598788751", null ],
    [ "updateParamTree", "dd/d55/classsoftware_1_1chipwhisperer_1_1common_1_1ui_1_1projectdiffwidget_1_1ProjectDiffWidget.html#aaa9e318ed703393e9a7cf89610524818", null ],
    [ "addedTree", "dd/d55/classsoftware_1_1chipwhisperer_1_1common_1_1ui_1_1projectdiffwidget_1_1ProjectDiffWidget.html#a981829a4f4467881576965caaa4e32b1", null ],
    [ "changedTree", "dd/d55/classsoftware_1_1chipwhisperer_1_1common_1_1ui_1_1projectdiffwidget_1_1ProjectDiffWidget.html#ab6906fd3d24048adb62e9717c03c1cfd", null ],
    [ "deletedTree", "dd/d55/classsoftware_1_1chipwhisperer_1_1common_1_1ui_1_1projectdiffwidget_1_1ProjectDiffWidget.html#a22c6825aa183df4fa6337d977eb5e9bd", null ]
];