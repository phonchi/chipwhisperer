var namespacesoftware_1_1chipwhisperer_1_1capture_1_1targets_1_1SimpleSerial =
[
    [ "SimpleSerial", "d9/d56/classsoftware_1_1chipwhisperer_1_1capture_1_1targets_1_1SimpleSerial_1_1SimpleSerial.html", "d9/d56/classsoftware_1_1chipwhisperer_1_1capture_1_1targets_1_1SimpleSerial_1_1SimpleSerial" ]
];