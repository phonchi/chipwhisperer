var ProjectTextEditor_8py =
[
    [ "ProjectEditor", "d5/d1e/classsoftware_1_1chipwhisperer_1_1common_1_1ui_1_1ProjectTextEditor_1_1ProjectEditor.html", "d5/d1e/classsoftware_1_1chipwhisperer_1_1common_1_1ui_1_1ProjectTextEditor_1_1ProjectEditor" ],
    [ "ProjectTextEditor", "d9/d6c/classsoftware_1_1chipwhisperer_1_1common_1_1ui_1_1ProjectTextEditor_1_1ProjectTextEditor.html", "d9/d6c/classsoftware_1_1chipwhisperer_1_1common_1_1ui_1_1ProjectTextEditor_1_1ProjectTextEditor" ],
    [ "ProjectHighlighter", "df/ddd/classsoftware_1_1chipwhisperer_1_1common_1_1ui_1_1ProjectTextEditor_1_1ProjectHighlighter.html", "df/ddd/classsoftware_1_1chipwhisperer_1_1common_1_1ui_1_1ProjectTextEditor_1_1ProjectHighlighter" ],
    [ "fontformat", "dd/d86/ProjectTextEditor_8py.html#a4509958a6872ff0910dce94fc604722a", null ],
    [ "STYLES", "dd/d86/ProjectTextEditor_8py.html#ab8f16bee0288aa31c33096fe8fb4c618", null ]
];