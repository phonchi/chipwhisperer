var ztex_8py =
[
    [ "OpenADCInterface_ZTEX", "d6/da8/classsoftware_1_1chipwhisperer_1_1capture_1_1scopes_1_1openadc__interface_1_1ztex_1_1OpenADCInterface__ZTEX.html", "d6/da8/classsoftware_1_1chipwhisperer_1_1capture_1_1scopes_1_1openadc__interface_1_1ztex_1_1OpenADCInterface__ZTEX" ],
    [ "usb", "dd/d7a/ztex_8py.html#a304a680450519fb390b34734f8a73b4f", null ]
];