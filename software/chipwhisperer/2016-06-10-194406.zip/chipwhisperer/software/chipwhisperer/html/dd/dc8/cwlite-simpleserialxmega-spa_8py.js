var cwlite_simpleserialxmega_spa_8py =
[
    [ "UserScript", "da/da0/classsoftware_1_1chipwhisperer_1_1capture_1_1scripts_1_1cwlite-simpleserialxmega-spa_1_1UserScript.html", "da/da0/classsoftware_1_1chipwhisperer_1_1capture_1_1scripts_1_1cwlite-simpleserialxmega-spa_1_1UserScript" ],
    [ "api", "dd/dc8/cwlite-simpleserialxmega-spa_8py.html#a516520bd4dcd77d2e1fd5ffbdb0b8d90", null ],
    [ "app", "dd/dc8/cwlite-simpleserialxmega-spa_8py.html#abf1e3d28260421a60b7ad0882c0c2c36", null ],
    [ "gui", "dd/dc8/cwlite-simpleserialxmega-spa_8py.html#ab5f9c7367f23264ce6feedd951ba8e2a", null ],
    [ "usercommands", "dd/dc8/cwlite-simpleserialxmega-spa_8py.html#acd034c3e1d25b120839a7e1bf1fdbed0", null ]
];