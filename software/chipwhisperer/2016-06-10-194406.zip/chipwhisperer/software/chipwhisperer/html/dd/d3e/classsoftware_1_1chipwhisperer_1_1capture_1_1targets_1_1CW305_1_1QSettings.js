var classsoftware_1_1chipwhisperer_1_1capture_1_1targets_1_1CW305_1_1QSettings =
[
    [ "setValue", "dd/d3e/classsoftware_1_1chipwhisperer_1_1capture_1_1targets_1_1CW305_1_1QSettings.html#a093d60964be76298749ac67b469f6c92", null ],
    [ "value", "dd/d3e/classsoftware_1_1chipwhisperer_1_1capture_1_1targets_1_1CW305_1_1QSettings.html#a0b1db1a0fdb7057db3a6ffd24845d257", null ]
];